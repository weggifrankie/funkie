# copy code from davids git hub
1: git init
2: git remote add origin https://github.com/davidopmi/camps.git
3: git pull origin master


# to check in the changes
    git status
    git add .
    git commit -m
    git push origin master
# to get the latest code
    git pull
